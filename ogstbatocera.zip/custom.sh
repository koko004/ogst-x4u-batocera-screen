#!/bin/bash

logo_folder='/userdata/OGST'
default_logo='start.mp4'
logo_file=""
loop=false
default_logo_loop=false

case "$1" in 
    start)  
        # init TFT screen
        [ `/sbin/lsmod | grep -c spi_s3c64xx` -ge 1 ] && rmmod spi_s3c64xx
        modprobe spi_s3c64xx force32b=1
        modprobe fbtft_device name=hktft9340 busnum=1 rotate=270 force32b=1

        # wait fb1 loaded
        N=0
        while ! test -e /dev/fb1 -o $N -gt 15; do
                sleep 1
                let N++
        done
		
		# rename fb1 to fb_ (trick to ovoid conflics with some emulators like reicast...)
		mv /dev/fb1 /dev/fb_
        
        logo_file=$default_logo && loop=default_logo_loop
    ;;
    stop)           logo_file='stop.mp4' && loop=false  ;;
	default)        logo_file=$default_logo && loop=default_logo_loop  ;;
3do)				logo_file='3do/video.mp4' && loop=true ;;
amiga)				logo_file='amiga/video.mp4' && loop=true ;;
amigacd32)			logo_file='amigacd32/video.mp4' && loop=true ;;
amstradcpc)			logo_file='amstradcpc/video.mp4' && loop=true ;;
apple2)				logo_file='apple2/video.mp4' && loop=true ;;
atari800)			logo_file='atari800/video.mp4' && loop=true ;;
atari2600)			logo_file='atari2600/video.mp4' && loop=true ;;
atari5200)			logo_file='atari5200/video.mp4' && loop=true ;;
atari7800)			logo_file='atari7800/video.mp4' && loop=true ;;
atarist)			logo_file='atarist/video.mp4' && loop=true ;;
atomiswave)			logo_file='atomiswave/video.mp4' && loop=true ;;
c64)				logo_file='c64/video.mp4' && loop=true ;;
cavestory)			logo_file='cavestory/video.mp4' && loop=true ;;
colecovision)		logo_file='colecovision/video.mp4' && loop=true ;;
dreamcast)			logo_file='dreamcast/video.mp4' && loop=true ;;
fba)				logo_file='fba/video.mp4' && loop=true ;;
fds)				logo_file='fds/video.mp4' && loop=true ;;
gameandwatch)		logo_file='gameandwatch/video.mp4' && loop=true ;;
gamegear)			logo_file='gamegear/video.mp4' && loop=true ;;
gb)					logo_file='gb/video.mp4' && loop=true ;;
gba)				logo_file='gba/video.mp4' && loop=true ;;
gbc)				logo_file='gbc/video.mp4' && loop=true ;;
gx4000)				logo_file='gx4000/video.mp4' && loop=true ;;
intellivision)		logo_file='intellivision/video.mp4' && loop=true ;;
jaguar)				logo_file='jaguar/video.mp4' && loop=true ;;
lynx)				logo_file='lynx/video.mp4' && loop=true ;;
mame)				logo_file='mame/video.mp4' && loop=true ;;
mastersystem)		logo_file='mastersystem/video.mp4' && loop=true ;;
megadrive)			logo_file='megadrive/video.mp4' && loop=true ;;
msx)				logo_file='msx/video.mp4' && loop=true ;;
n64)				logo_file='n64/video.mp4' && loop=true ;;
naomi)				logo_file='naomi/video.mp4' && loop=true ;;
neogeo)				logo_file='neogeo/video.mp4' && loop=true ;;
neogeocd)			logo_file='neogeocd/video.mp4' && loop=true ;;
nes)				logo_file='nes/video.mp4' && loop=true ;;
ngp)				logo_file='ngp/video.mp4' && loop=true ;;
ngpc)				logo_file='ngpc/video.mp4' && loop=true ;;
o2em)				logo_file='o2em/video.mp4' && loop=true ;;
pcenginecd)			logo_file='pcenginecd/video.mp4' && loop=true ;;
pcengine)			logo_file='pcengine/video.mp4' && loop=true ;;
pcfx)				logo_file='pcfx/video.mp4' && loop=true ;;
pokemini)			logo_file='pokemini/video.mp4' && loop=true ;;
prboom)				logo_file='prboom/video.mp4' && loop=true ;;
psp)				logo_file='psp/video.mp4' && loop=true ;;
psx)				logo_file='psx/video.mp4' && loop=true ;;
satellaview)		logo_file='satellaview/video.mp4' && loop=true ;;
saturn)				logo_file='saturn/video.mp4' && loop=true ;;
scummvm)			logo_file='scummvm/video.mp4' && loop=true ;;
sega32x)			logo_file='sega32x/video.mp4' && loop=true ;;
segacd)				logo_file='segacd/video.mp4' && loop=true ;;
sg1000)				logo_file='sg1000/video.mp4' && loop=true ;;
snes)				logo_file='snes/video.mp4' && loop=true ;;
sufami)				logo_file='sufami/video.mp4' && loop=true ;;
supergrafx)			logo_file='supergrafx/video.mp4' && loop=true ;;
thomson)			logo_file='thomson/video.mp4' && loop=true ;;
vectrex)			logo_file='vectrex/video.mp4' && loop=true ;;
virtualboy)			logo_file='virtualboy/video.mp4' && loop=true ;;
wswan)				logo_file='wswan/video.mp4' && loop=true ;;
wswanc)				logo_file='atari800/video.mp4' && loop=true ;;
x68000)				logo_file='x68000/video.mp4' && loop=true ;;
zx81)				logo_file='zx81/video.mp4' && loop=true ;;
zxspectrum)			logo_file='zxspectrum/video.mp4' && loop=true ;;
   *)
esac


draw_logo () {
	loop=0
	if [ $3 = true ]; then loop=-1; fi
    dd if=/dev/zero of=/dev/fb_ 2>/dev/null >/dev/null   #clear before draw
    ffmpeg -hide_banner -re -stream_loop $loop -i $1/$2 -c:v rawvideo -pix_fmt rgb565le -f fbdev /dev/fb_ 2>/dev/null >/dev/null &
}


# draw logo
if [ "$logo_file" != "" ]; then
	if [ "$(pidof ffmpeg)" ] ; then
	    kill -9 "$(pidof ffmpeg)"
	fi
	draw_logo $logo_folder $logo_file $loop
fi

if [ "$1" != "start" ] && [ "$1" != "stop" ] ; then
	pid="$(pidof -s python)"
    while [ "$(pidof -s python)" = $pid ]; do  # emulatorlaucher is running
        sleep 1
    done
	if [ "$(pidof ffmpeg)" ] ; then  # when emulatorlaucher ends, kill ffmpeg if is running
	    kill -9 "$(pidof ffmpeg)"
	fi
	draw_logo $logo_folder $default_logo $default_logo_loop
fi

exit 1  



